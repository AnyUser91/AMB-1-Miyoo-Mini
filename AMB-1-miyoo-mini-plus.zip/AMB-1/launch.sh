#!/bin/sh
cd "$(dirname "$0")"
export LD_LIBRARY_PATH="$(pwd)/lib:$LD_LIBRARY_PATH"
./amb 2>log.txt
