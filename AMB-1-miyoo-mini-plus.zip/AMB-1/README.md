# AMB-1 on the Miyoo Mini Plus (OnionOS)

AMB-1 is Charles Vestal's generative ambient machine for the M-VAVE FM-1 (see the [main README](../README.md)).
This folder runs the same app, unchanged, on a Miyoo Mini Plus under OnionOS: the engine, the eight pieces, the
screen and the way it behaves are the FM-1's. Only the panel is new: the FM-1's 27 keys, 14 buttons and 7 knobs
become the Miyoo's D-pad, face buttons, shoulders, START and SELECT.

**Status: tested on a computer, not yet on a Miyoo.** The front end and the app run against a faked SDL in
`miyoo/test` (46 checks: every control, the scale editing, saving, the sound), and the ARM package builds. Nobody has
run it on the handheld yet.

## Install

1. Copy the `AMB-1` folder to `App/` on the SD card (`/mnt/SDCARD/App/AMB-1`).
2. Open it from OnionOS's Apps. The first launch shows the controls; any button closes them.

It writes `amb.sav` (your pieces and the volume) and `log.txt` (the last run's messages) in its own folder.
Leaving with MENU keeps what you changed.

## Controls

| | |
|---|---|
| D-pad UP / DOWN | Pick one of the four knobs (the picked one is underlined, and numbered on the right) |
| D-pad LEFT / RIGHT | Turn it; hold to go fast |
| L / R | Previous / next page: Garden, Pad, Bells, Bass, Pulse, Space, Setup |
| A | Grow / rest |
| B | Freeze |
| X | Next chord |
| Y | Home page; Y held with L / R: the tempo |
| START | Save; held for 1.5 s: the piece back to its recipe |
| SELECT held, then | LEFT / RIGHT: move along the twelve notes (left bar); A: add or take out that note; UP / DOWN: the bells' octave; L / R: previous / next piece; X / Y: next / previous mode; B / START: volume down / up |
| SELECT alone | The help screen |
| MENU | Save and quit |

The left bar shows the twelve notes: filled is in the scale, the root is teal. The right bar shows the knob you are on,
whether SELECT is held, and the volume (the app's own, set with SELECT + B / START). The app uses no MENU
combinations, so OnionOS's own system hotkeys are not touched by it.

## What is not here

- The FM-1's USB, MIDI in and out, MIDI clock sync, the USB recording and the screen reader link: the Miyoo has no such
  ports. The tempo is set on the Garden page (or with Y + L / R) and nothing follows an outside clock.
- The hold-a-button help cards still name the FM-1's buttons (OCT+, SEL, ...).
- The battery in the header is read from the kernel's power supply; if the Miyoo does not publish one there, the header
  shows none.

## Building

Needs the Miyoo Mini toolchain ([union-miyoomini-toolchain](https://github.com/shauninman/union-miyoomini-toolchain):
its Docker image, or its tarball, `miyoomini-toolchain-buildroot` release v0.0.3) unpacked at `/opt/miyoomini-toolchain`
(or `MIYOO_TOOLCHAIN=...`), and the submodule (`git submodule update --init --recursive`):

```
miyoo/build.sh              # miyoo/build/AMB-1/
sh miyoo/test/run_tests.sh  # the front end, on this computer
```

How it works: `amb_miyoo.c` is a front end for fm1-base's host simulator (`base/host/plat_host.c`, the one the tests
and the browser emulator use), in the way `base/web/emu/emu_web.c` is. The simulator runs the app; the front end
draws the 240 x 240 screen at 2x, turns buttons into the FM-1's inputs, and plays the sound through SDL 1.2 from a ring
the main thread fills (SDL's audio thread only copies from it). The Mini Plus's panel shows SDL's picture upside down,
so everything is drawn upright into a buffer and copied to the screen turned 180 degrees (`MM_ROTATE180`, in the code;
`miyoo/test` checks it). `build.sh` patches one line of `plat_host.c` in a copy
(`plat_battery`), so `base/` stays as it is.

## Licence

MPL-2.0, as AMB-1 (see `LICENSE`). Built on [AMB-1](https://github.com/charlesvestal/fm1-amb) and
[fm1-base](https://github.com/charlesvestal/fm1-base); not an official part of either. Button codes from
[OnionOS](https://github.com/OnionUI/Onion)'s `keymap_hw.h`.
